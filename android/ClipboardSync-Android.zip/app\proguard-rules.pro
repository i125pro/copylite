# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.clipboard.app.** { *; }
