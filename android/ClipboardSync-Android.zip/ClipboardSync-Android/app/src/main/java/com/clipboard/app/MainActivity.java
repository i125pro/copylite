package com.clipboard.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "clipboard_prefs";
    private static final String KEY_SERVER = "server_url";
    private static final String KEY_TOKEN = "token";
    private static final String DEFAULT_SERVER = "http://192.168.0.24:8086";

    private EditText etServerUrl, etToken, etUpload;
    private TextView tvStatus, tvDownload;
    private Button btnTest, btnSave, btnUpload, btnReadClipboard, btnDownload, btnCopyToDevice;

    private SharedPreferences prefs;
    private String serverUrl;
    private String token;
    private String lastContent = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        serverUrl = prefs.getString(KEY_SERVER, DEFAULT_SERVER);
        token = prefs.getString(KEY_TOKEN, "");

        etServerUrl = findViewById(R.id.etServerUrl);
        etToken = findViewById(R.id.etToken);
        etUpload = findViewById(R.id.etUpload);
        tvStatus = findViewById(R.id.tvStatus);
        tvDownload = findViewById(R.id.tvDownload);
        btnTest = findViewById(R.id.btnTest);
        btnSave = findViewById(R.id.btnSave);
        btnUpload = findViewById(R.id.btnUpload);
        btnReadClipboard = findViewById(R.id.btnReadClipboard);
        btnDownload = findViewById(R.id.btnDownload);
        btnCopyToDevice = findViewById(R.id.btnCopyToDevice);

        etServerUrl.setText(serverUrl);
        etToken.setText(token);

        btnTest.setOnClickListener(v -> testConnection());
        btnSave.setOnClickListener(v -> saveSettings());
        btnUpload.setOnClickListener(v -> uploadClipboard());
        btnReadClipboard.setOnClickListener(v -> readFromClipboard());
        btnDownload.setOnClickListener(v -> downloadClipboard());
        btnCopyToDevice.setOnClickListener(v -> copyToDevice());

        startAutoRefresh();
    }

    private String authUrl(String path) {
        String url = serverUrl + path;
        if (token != null && !token.isEmpty()) {
            String sep = url.contains("?") ? "&" : "?";
            url += sep + "token=" + URLEncoder.encode(token, java.nio.charset.StandardCharsets.UTF_8);
        }
        return url;
    }

    // ========== Settings ==========
    private void saveSettings() {
        String url = etServerUrl.getText().toString().trim();
        String tk = etToken.getText().toString().trim();
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        if (!url.isEmpty()) {
            serverUrl = url;
            token = tk;
            prefs.edit().putString(KEY_SERVER, url).putString(KEY_TOKEN, tk).apply();
            toast("设置已保存");
            testConnection();
        }
    }

    private void testConnection() {
        executor.execute(() -> {
            boolean ok = false;
            try {
                URL url = new URL(serverUrl + "/api/health");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);
                ok = conn.getResponseCode() == 200;
                conn.disconnect();
            } catch (Exception ignored) {}
            boolean finalOk = ok;
            handler.post(() -> {
                if (finalOk) {
                    tvStatus.setText("已连接");
                    tvStatus.setTextColor(getColor(R.color.success));
                } else {
                    tvStatus.setText("未连接");
                    tvStatus.setTextColor(getColor(R.color.error));
                }
            });
        });
    }

    // ========== Clipboard Operations ==========
    private void uploadClipboard() {
        String text = etUpload.getText().toString();
        if (text.isEmpty()) { toast("请输入文本"); return; }
        executor.execute(() -> {
            try {
                URL url = new URL(authUrl("/api/clipboard"));
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                JSONObject body = new JSONObject();
                body.put("content", text);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes("UTF-8"));
                }
                int code = conn.getResponseCode();
                conn.disconnect();
                handler.post(() -> {
                    if (code == 200) {
                        lastContent = text;
                        toast("上传成功");
                    } else if (code == 401) {
                        toast("Token 无效，请检查设置");
                    } else {
                        toast("上传失败: HTTP " + code);
                    }
                });
            } catch (Exception e) {
                handler.post(() -> toast("上传失败: " + e.getMessage()));
            }
        });
    }

    private void downloadClipboard() {
        executor.execute(() -> {
            try {
                URL url = new URL(authUrl("/api/clipboard"));
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                int code = conn.getResponseCode();
                if (code == 200) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();
                    JSONObject data = new JSONObject(sb.toString());
                    String content = data.optString("content", "");
                    handler.post(() -> {
                        tvDownload.setText(content);
                        lastContent = content;
                        toast("已获取剪贴板内容");
                    });
                } else if (code == 401) {
                    handler.post(() -> toast("Token 无效，请检查设置"));
                }
                conn.disconnect();
            } catch (Exception e) {
                handler.post(() -> toast("下载失败: " + e.getMessage()));
            }
        });
    }

    private void readFromClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence text = cm.getPrimaryClip().getItemAt(0).getText();
            if (text != null) {
                etUpload.setText(text.toString());
                toast("已从剪贴板读取");
            }
        } else {
            toast("剪贴板为空");
        }
    }

    private void copyToDevice() {
        String text = tvDownload.getText().toString();
        if (text.isEmpty()) { toast("没有内容可复制"); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("clipboard", text));
            toast("已复制到剪贴板");
        }
    }

    // ========== Auto Refresh ==========
    private void startAutoRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                executor.execute(() -> {
                    try {
                        URL url = new URL(authUrl("/api/clipboard"));
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setConnectTimeout(5000);
                        conn.setReadTimeout(5000);
                        if (conn.getResponseCode() == 200) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) sb.append(line);
                            reader.close();
                            JSONObject data = new JSONObject(sb.toString());
                            String content = data.optString("content", "");
                            String updatedAt = data.optString("updated_at", "—");
                            if (!content.isEmpty() && !content.equals(lastContent)) {
                                lastContent = content;
                                handler.post(() -> {
                                    tvDownload.setText(content);
                                    tvStatus.setText("已连接 · 更新于 " + updatedAt);
                                    tvStatus.setTextColor(getColor(R.color.success));
                                });
                            }
                        }
                        conn.disconnect();
                    } catch (Exception ignored) {}
                });
                handler.postDelayed(this, 5000);
            }
        }, 1000);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
        handler.removeCallbacksAndMessages(null);
    }
}
