package com.clipboard.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private EditText editServerUrl;
    private Button btnSave, btnTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        editServerUrl = findViewById(R.id.edit_server_url);
        btnSave = findViewById(R.id.btn_save);
        btnTest = findViewById(R.id.btn_test);

        SharedPreferences prefs = getSharedPreferences("clipboard_config", MODE_PRIVATE);
        editServerUrl.setText(prefs.getString("server_url", "http://192.168.0.24:8086"));

        btnSave.setOnClickListener(v -> saveConfig());
        btnTest.setOnClickListener(v -> testConnection());
    }

    private void saveConfig() {
        String url = editServerUrl.getText().toString().trim();
        if (url.isEmpty()) {
            Toast.makeText(this, "请输入服务器地址", Toast.LENGTH_SHORT).show();
            return;
        }
        // Remove trailing slash
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);

        SharedPreferences prefs = getSharedPreferences("clipboard_config", MODE_PRIVATE);
        prefs.edit().putString("server_url", url).apply();
        Toast.makeText(this, "保存成功", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void testConnection() {
        String url = editServerUrl.getText().toString().trim();
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        final String testUrl = url;

        btnTest.setEnabled(false);
        btnTest.setText("测试中...");

        new Thread(() -> {
            boolean ok = false;
            try {
                java.net.URL u = new java.net.URL(testUrl + "/api/health");
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);
                ok = (conn.getResponseCode() == 200);
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
            final boolean connected = ok;
            runOnUiThread(() -> {
                btnTest.setEnabled(true);
                if (connected) {
                    btnTest.setText("连接成功 ✓");
                    Toast.makeText(this, "服务器连接正常", Toast.LENGTH_SHORT).show();
                } else {
                    btnTest.setText("连接失败 ✗");
                    Toast.makeText(this, "无法连接服务器", Toast.LENGTH_SHORT).show();
                }
                btnTest.postDelayed(() -> btnTest.setText("测试连接"), 2000);
            });
        }).start();
    }
}
