package com.clipboard.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText editUpload, editDownload;
    private TextView tvStatus, tvLastUpdate;
    private Button btnUpload, btnDownload, btnCopy, btnPaste, btnSettings;
    private ImageView ivStatusDot;

    private String serverUrl = "http://192.168.0.24:8086";
    private String lastContent = "";
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean autoRefresh = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Load config
        SharedPreferences prefs = getSharedPreferences("clipboard_config", MODE_PRIVATE);
        serverUrl = prefs.getString("server_url", serverUrl);

        // Bind views
        editUpload = findViewById(R.id.edit_upload);
        editDownload = findViewById(R.id.edit_download);
        tvStatus = findViewById(R.id.tv_status);
        tvLastUpdate = findViewById(R.id.tv_last_update);
        btnUpload = findViewById(R.id.btn_upload);
        btnDownload = findViewById(R.id.btn_download);
        btnCopy = findViewById(R.id.btn_copy);
        btnPaste = findViewById(R.id.btn_paste);
        btnSettings = findViewById(R.id.btn_settings);
        ivStatusDot = findViewById(R.id.iv_status_dot);

        // Button listeners
        btnUpload.setOnClickListener(v -> uploadClipboard());
        btnDownload.setOnClickListener(v -> downloadClipboard());
        btnCopy.setOnClickListener(v -> copyToDevice());
        btnPaste.setOnClickListener(v -> pasteFromDevice());
        btnSettings.setOnClickListener(v -> openSettings());

        // Initial fetch
        checkConnection();
        startAutoRefresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences prefs = getSharedPreferences("clipboard_config", MODE_PRIVATE);
        serverUrl = prefs.getString("server_url", serverUrl);
        checkConnection();
    }

    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    private void checkConnection() {
        new Thread(() -> {
            boolean ok = false;
            try {
                URL url = new URL(serverUrl + "/api/health");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);
                conn.setRequestMethod("GET");
                int code = conn.getResponseCode();
                ok = (code == 200);
                conn.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
            final boolean connected = ok;
            handler.post(() -> {
                if (connected) {
                    ivStatusDot.setImageResource(R.drawable.dot_green);
                    tvStatus.setText("已连接");
                } else {
                    ivStatusDot.setImageResource(R.drawable.dot_red);
                    tvStatus.setText("未连接");
                }
            });
            if (connected) {
                fetchClipboard();
            }
        }).start();
    }

    private void fetchClipboard() {
        new Thread(() -> {
            try {
                URL url = new URL(serverUrl + "/api/clipboard");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                conn.disconnect();

                JSONObject json = new JSONObject(sb.toString());
                String content = json.optString("content", "");
                String updatedAt = json.optString("updated_at", "");

                handler.post(() -> {
                    if (!content.isEmpty()) {
                        editDownload.setText(content);
                        lastContent = content;
                    }
                    if (!updatedAt.isEmpty()) {
                        tvLastUpdate.setText("更新于: " + updatedAt);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void uploadClipboard() {
        String text = editUpload.getText().toString();
        if (text.trim().isEmpty()) {
            Toast.makeText(this, "请输入文本", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            try {
                URL url = new URL(serverUrl + "/api/clipboard");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                JSONObject json = new JSONObject();
                json.put("content", text);

                OutputStream os = conn.getOutputStream();
                os.write(json.toString().getBytes("UTF-8"));
                os.flush();
                os.close();

                int code = conn.getResponseCode();
                conn.disconnect();

                handler.post(() -> {
                    if (code == 200) {
                        Toast.makeText(this, "上传成功", Toast.LENGTH_SHORT).show();
                        editUpload.setText("");
                        fetchClipboard();
                    } else {
                        Toast.makeText(this, "上传失败: " + code, Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                handler.post(() -> Toast.makeText(this, "上传失败: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void downloadClipboard() {
        fetchClipboard();
        handler.postDelayed(() -> {
            if (!editDownload.getText().toString().isEmpty()) {
                Toast.makeText(this, "已获取剪贴板内容", Toast.LENGTH_SHORT).show();
            }
        }, 500);
    }

    private void copyToDevice() {
        String text = editDownload.getText().toString();
        if (text.isEmpty()) {
            Toast.makeText(this, "没有内容可复制", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("clipboard", text));
        Toast.makeText(this, "已复制到剪贴板", Toast.LENGTH_SHORT).show();
    }

    private void pasteFromDevice() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence text = cm.getPrimaryClip().getItemAt(0).getText();
            if (text != null) {
                editUpload.setText(text.toString());
                Toast.makeText(this, "已从剪贴板读取", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "剪贴板为空", Toast.LENGTH_SHORT).show();
        }
    }

    private void startAutoRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (autoRefresh) {
                    fetchClipboard();
                }
                handler.postDelayed(this, 5000);
            }
        }, 5000);
    }
}
